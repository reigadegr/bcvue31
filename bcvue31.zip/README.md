# bcvue31

## Project setup
```
npm install -force
```

### Compiles and hot-reloads for development
```
npm run serve
```
### 如果有问题看这里：
```
npm install normalize.css –save
```
### 如果还不行
```
npm install normalize.css -force
```
### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
